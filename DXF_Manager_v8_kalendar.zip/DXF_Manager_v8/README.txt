DXF Manager v8

Nová záložka Kalendář:
- měsíční kalendář
- přepínání mezi měsíci
- tlačítko Dnes
- kliknutí na konkrétní den
- typ záznamu: Událost, Poznámka nebo Připomínka
- datum, čas od/do, název a poznámka
- úprava a smazání záznamů

Kalendář je také na hlavním Přehledu:
- počet záznamů dnes
- počet záznamů během následujících 7 dnů
- počet záznamů v aktuálním měsíci
- nejbližší událost
- čtyři nejbližší záznamy

Kliknutím na záznam na Přehledu se otevře daný den v kalendáři.
Data se ukládají společně se skladem a objednávkami a jsou zahrnuta v JSON záloze.
